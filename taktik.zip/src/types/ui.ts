export type EdgeDockTab = "cmd" | "console";
