import type { BoardCell } from "@/types/core";

export type GridPos = BoardCell;
