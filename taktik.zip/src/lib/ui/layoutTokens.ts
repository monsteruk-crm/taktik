export const BORDER = 2;
export const GAP_SM = 6;
export const GAP_MD = 8;
export const PAD = 8;
