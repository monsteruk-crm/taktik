isometric tactical unit token, motorized unit,


visual style: Brutalist Constructivism,
cold war military operational aesthetic,
constructivist diagram language,
flat color fields only,
diagrammatic, not illustrative,
clean edges,
hard shapes,
no decoration,

form rules:
silhouette-first,
abstract irregular block composition,
shoulders and upper mass clearly visible,
asymmetric silhouette allowed (especially for special unit),
no realism,
no identifiable real-world equipment,
no surface detail,
no micro-textures,

base:
flat brutalist slab,
rectangular,
hard edges,
single flat fill,
no bevel,
no shadow,

color (Player A):
mostly neutral body,
Player A primary accent: #1F4E79 used sparingly,
high contrast,
max 1 accent color + neutrals,

absolute prohibitions:
no gradients,
no glow,
no soft shadows,
no lighting effects,
no cinematic styling,
no depth of field,
no rounded corners,
no 3D render look,

output:
single Blender OBJ
