tactical card design,
operational advantage card for a military operations board game,
this is NOT a reward screen,
this is NOT a power fantasy,
this is NOT a collectible showcase,

visual style: Brutalist Constructivism,
cold war military operational aesthetic,
constructivist propaganda poster layout,
diagrammatic, not illustrative,
flat color fields only,
no gradients,
no textures,
no noise,
no glitch,
no effects,
no lighting,
no shadows,
no emboss,
no bevel,
no metallic surfaces,

brutalist execution:
flat rectangular slab,
hard edges,
no rounded corners,
no decorative frame,
no border ornamentation,

constructivist rules:
bold uppercase typography dominant,
icon plus text only,
large negative space,
strict grid alignment,
asymmetric but disciplined composition,
clear hierarchy favoring title and icon,

tone and intent:
operational,
supportive,
procedural,
controlled,
authoritative but neutral,
feels like a command authorization,
feels like additional resources being allocated,
feels helpful but not exciting,

content:
TITLE: RAPID SUPPLY CONVOY,
short functional clarifying line allowed if necessary,
no slogans,
no narrative language,

iconography:
abstract operational-support symbol,
simple geometric construction,
single visual weight,
no distortion,
no realism,
no illustrative metaphor,

absolute prohibitions:
no realism,
no fantasy,
no sci-fi,
no cyberpunk,
no dramatic emphasis,
no expressive flourish,
no rarity signaling,
no “special” framing,

output:
single flat PNG card,
front face only,
no background outside the card
