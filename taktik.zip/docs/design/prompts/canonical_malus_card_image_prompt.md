tactical card design,
administrative restriction notice for a military operations board game,
this is NOT a villain card and NOT a cinematic threat screen,

visual style: Brutalist Constructivism,
cold war military operational aesthetic,
constructivist propaganda poster layout,
diagrammatic, not illustrative,
flat color fields only,
no gradients,
no textures,
no noise,
no glitch,
no effects,
no lighting,
no shadows,
no emboss,
no bevel,
no metallic surfaces,

brutalist execution:
flat rectangular slab,
hard edges,
no rounded corners,
no decorative frame,
no border ornamentation,

constructivist rules:
bold uppercase typography dominant,
icon plus text only,
large negative space,
strict grid alignment,
asymmetric but disciplined composition,

tone and intent:
bureaucratic,
procedural,
impersonal,
authoritative,
cold,
boring by design,
feels like a printed operations directive,
feels like a regulation that ruins a plan,

content:
TITLE: ENEMY DISINFORMATION,
short secondary text allowed but minimal,
no slogans,
no narrative language,

iconography:
abstract information-blockage symbol,
simple geometric construction,
single visual weight,
no distortion,
no realism,

absolute prohibitions:
no realism,
no sci-fi,
no cyberpunk,
no high-tech UI,
no holograms,
no scanlines,
no cinematic composition,
no expressive drama,
no decorative textures,
no friendly tone,
no personality

output:
single flat PNG card,
front face only,
no background outside the card
