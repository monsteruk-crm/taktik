tactical card design,
reaction-only tactical modifier for a military operations board game,
this is NOT a special ability card,
this is NOT a heroic moment,
this is NOT a cinematic effect,

visual style: Brutalist Constructivism,
cold war military operational aesthetic,
constructivist propaganda poster layout,
diagrammatic, not illustrative,
flat color fields only,
no gradients,
no textures,
no noise,
no glitch,
no effects,
no lighting,
no shadows,
no emboss,
no bevel,
no metallic surfaces,

brutalist execution:
flat rectangular slab,
hard edges,
no rounded corners,
no decorative frame,
no border ornamentation,

constructivist rules:
bold uppercase typography dominant,
icon plus text only,
large negative space,
strict grid alignment,
asymmetric but controlled composition,
clear visual hierarchy,
instant legibility at small size,

tone and intent:
procedural,
situational,
temporary,
impersonal,
clinical,
matter-of-fact,
feels like a checkbox applied during resolution,
feels like a rule exception, not a power,

content:
TITLE: DENSE FOG,
very short clarifying line allowed if needed,
no slogans,
no narrative language,

iconography:
abstract tactical-condition symbol,
simple geometric construction,
single visual weight,
no distortion,
no realism,
no metaphor illustration,

absolute prohibitions:
no realism,
no fantasy,
no sci-fi,
no cyberpunk,
no dramatic lighting,
no speed lines,
no motion blur,
no expressive symbolism,
no personality,
no “cool factor”,

output:
single flat PNG card,
front face only,
no background outside the card
