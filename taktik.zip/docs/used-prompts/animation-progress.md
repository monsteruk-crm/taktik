### TASK
Make TAKTIK’s board FX feel **much more spectacular and satisfying** without violating the Brutalist Constructivism rules.

Right now the animation plumbing exists, but the feedback is **too fast, too small, too subtle**. Fix by:
- increasing **scale + dwell time**
- using **multi-stage sequences** (LOCK → STRIKE → CONFIRM)
- adding **more geometry layers** (bars, brackets, stamps, shards, rings)
- adding a **hard “hit-stop”** feel (brief freeze / hold) — mechanical, not playful

UI ONLY. Do not change engine logic, phases, reducers, or rules.

---

### NON-NEGOTIABLE STYLE + MOTION RULES
Follow:
- `docs/design/brutalist_constructivism_locked_ai_prompt_system.md` (global style + negatives)
- `docs/design/brutalist_constructivism_visual_style_bible_markdown.md` (motion rules: cut/slide/snap; no easing personality)
- `docs/ui/UI_GLOBAL_RULES.md` + `AGENTS.md` UI doctrine

Strict forbiddens:
- no glow, blur, gradients, soft shadows, rounded corners
- no bounce, elastic, playful easing
- no layout shift / reflow
- FX must be **board-space overlays**, transform-only animations OK

Respect reduced motion:
- if reduced motion: **no scaling pulses / no traveling shards**
- still show **big, high-contrast stamps** with longer hold

---

### FILES TO READ (PRIORITY)
1) `src/components/IsometricBoard.tsx`
2) `src/components/fx/BoardFxLayer.tsx` (or wherever FX plumbing lives now)
3) `src/lib/ui/motion.ts` (or motion tokens)
4) `src/lib/ui/semanticColors.ts`
5) any existing FX css/module files used by BoardFxLayer
6) `docs/design/brutalist_constructivism_visual_style_bible_markdown.md`
7) `docs/design/brutalist_constructivism_locked_ai_prompt_system.md`
8) `docs/ui/UI_GLOBAL_RULES.md`

---

### GOAL (WHAT “SPECTACULAR” MEANS HERE)
Not fireworks. It’s **authoritative operations feedback**:
- bigger shapes
- thicker strokes
- clearer sequencing
- longer confirmation hold
- more “procedural violence” (stamps, bars, brackets, kill marks)

Think: **command-console strike confirmation**, not arcade VFX.

---

## IMPLEMENTATION REQUIREMENTS

### 1) Introduce FX timing tokens (single source of truth)
Add to `src/lib/ui/motion.ts` (or your existing token file):

- `FX_LOCK_MS = 220`
- `FX_SHOT_MS = 180`
- `FX_IMPACT_MS = 260`
- `FX_HITSTOP_MS = 90` (brief hold)
- `FX_CONFIRM_MS = 900` (this is the big improvement)
- `FX_TOTAL_ATTACK_MS = FX_LOCK_MS + FX_SHOT_MS + FX_IMPACT_MS + FX_HITSTOP_MS + FX_CONFIRM_MS`

These values must be easy to tune.

**Mechanical easing rule:** use `linear` or `steps(1,end)` for hard snaps. Avoid ease-in-out.

---

### 2) Upgrade ATTACK FX to a 3-stage sequence

#### Stage A — LOCK (while pendingAttack exists)
Make it bold and readable:
- line attacker→target: **thicker** (min 6px at normal zoom)
- add **target brackets**: 4 corner “L” shapes OR diamond frame (hard edged)
- add **attacker wedge**: small red direction wedge at attacker anchor pointing to target

If you currently render a thin line: keep SVG, but increase stroke + add corner marks.

LOCK animation:
- quick “type-in” effect using `stroke-dasharray` reveal OR clip-path reveal
- duration: `FX_LOCK_MS`
- then HOLD visible while pendingAttack is active

Reduced motion: no reveal; just appear instantly.

#### Stage B — STRIKE (triggered on dice roll / lastRoll transition)
Spawn a short-lived STRIKE package:
1) **Tracer bar** (not a hairline):
    - render as a thick red rectangle rotated to angle
    - animate `scaleX(0→1)` from attacker origin
    - duration `FX_SHOT_MS`

2) **Impact ring + shards** at target:
    - diamond ring: a rotated square with thick border (no glow)
    - animate ring: `scale(0.75→1.25)` + opacity `1→0`
    - 4 “shards”: small rectangles that snap outward 8–14px (transform translate)
    - duration `FX_IMPACT_MS`

3) **Hit-stop**:
    - after impact begins, hold final impact frame for `FX_HITSTOP_MS`
    - implement by delaying fade-out / removal rather than pausing the world

Reduced motion: no moving shards; just show a big ring flash + stamp (below) with longer hold.

#### Stage C — CONFIRM (when pendingAttack clears)
This is where your “anemic X” must become **a satisfying confirmation**.

On resolve, render a **big target-stamp** for `FX_CONFIRM_MS`:

- If HIT / unit destroyed:
    - giant red diagonal bar across tile (like a censor slash), plus
    - a large black “KIA / DESTROYED” slab stamp with red stripe (top-left of tile), plus
    - a thick X (two rectangles) that stays visible for ~65% of confirm window
    - optionally add a **secondary “REMOVED” micro-label** in ink

- If HIT but unit survives:
    - stamp reads “HIT”
    - no KIA bar, but keep ring + brackets for confirmation hold

- If MISS:
    - stamp reads “MISS”
    - use ink/neutral (avoid new accent colors)

IMPORTANT:
- CONFIRM must use the stored snapshot so it still renders even if the target unit disappears.
- Confirmation visuals must be **bigger** than the unit sprite footprint (it’s OK if it overlaps adjacent tiles slightly, but keep within board layer, no panel overlays).

Reduced motion:
- still show the big stamp and diagonal bar; just no scaling/flying shards.

---

### 3) Add “unit disappears” readability (ghost footprint)
When a unit is removed (killed), the disappearance is currently abrupt.

Add a UI-only “ghost footprint” for 450–650ms:
- render a neutral slab silhouette (simple rectangle/diamond) at the unit anchor
- it fades out linearly
- this makes the “removal” legible and weighty without adding cinematic effects

Do NOT require engine events. Infer by:
- comparing previous units list to current units list in BoardFxLayer
- for any removed unit ID, spawn a `UNIT_REMOVED_GHOST` fx item at last known position (keep a ref map of prior positions)

Reduced motion: same, just fade.

---

### 4) Make effects/tactics application feel like “administrative stamps”
Your “unit affected” pulses should be:
- larger
- longer
- more directive-looking

On new effects applied:
- render a **yellow stamp slab** near the unit (top edge of tile):
    - yellow rectangle with thick ink border
    - text: “EFFECT” or use a safe short label if available (e.g. effect.kind)
- plus a diamond frame around unit for 220–320ms
- total dwell for stamp: 600–900ms (depends on reduced motion)

Avoid cute pulses. Make it procedural.

---

### 5) Ensure no perf regressions
- Keep FX as ephemeral items removed by `setTimeout`.
- No per-frame state updates.
- All animations via CSS keyframes or transitions.
- Prefer a single absolutely-positioned FX root layer with child items.

---

## DELIVERABLES

### Code
- Update FX system to the new 3-stage attack sequence + bigger shapes + longer confirm.
- Add ghost footprint for removed units.
- Upgrade effect application to stamp + frame.

### Docs (MANDATORY)
Update:
1) `docs/progress.md` (BEFORE / NOW / NEXT + files touched)
2) `docs/manual-e2e-test.md`:
    - add checks for:
        - lock visuals visible while targeting
        - strike shows tracer + impact
        - confirm stamp persists long enough to be noticed
        - ghost footprint appears when a unit is removed
        - reduced motion: no travel/scale, but stamps still appear

If you add any new doc file, update `docs/README.md` and `docs/meta/DOCS_INDEX.md`.

### Response format (MANDATORY)
- Files read
- Files changed
- What changed (brief)
- Docs updated (exact sections)
- Memory updates (“none”)

---

## VISUAL SPEC QUICK NUMBERS (USE THESE)
- Line thickness: 6–10px depending on zoom
- Corner bracket thickness: 4–6px
- Confirm stamp height: ~18–22px with uppercase text
- Confirm dwell: **900ms** (minimum) — THIS is the main “less anemic” change
- Total sequence typical: ~1.6s (lock + strike + confirm), reduced-motion still ~1.0s via stamps

Proceed.
